<nav class="navbar navbar-expand-sm navbar-dark bg-dark ">
    <a class="navbar-brand font-weight-bold" href="#"><h4>Canteen Admin Portal</h4></a>
    <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarMenu">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarMenu">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminindex.php"><h6>Home</h6></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="addmenu.php"><h6>Menu</h6></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminindex.php"><h6>Orders</h6></a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#"><h6></h6></a>
            </li>
            <li class="nav-item">
                <a class="btn btn-warning" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>





    
   

